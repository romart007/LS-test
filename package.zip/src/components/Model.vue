<template>
  <Main>
    <b-container
      class="main-container d-flex align-items-center justify-content-center"
    >
      <Interface :inputValue="appData.interface" />
      <svg width="500" height="500" style="position: absolute">
        <line
          data-v-76ee2aa9=""
          x1="79"
          y1="40"
          x2="79"
          y2="151"
          stroke="black"
        />
      </svg>
      <Server :inputValue="appData.server" />
      <AppGroup :inputValue="appData.appGroup" />
      <Mtv :inputValue="appData.mtv" />
      <Funcs :inputValue="appData.funcs" />
      <Application :inputValue="applicationTotal" />
    </b-container>
  </Main>
</template>
<script>
import Main from "@/layouts/Main";
import Application from "@/components/Application";
import Interface from "@/components/Interface";
import Server from "@/components/Server";
import AppGroup from "@/components/AppGroup";
import Mtv from "@/components/Mtv";
import Funcs from "@/components/Funcs";
import { bus } from "../main";

export default {
  components: { Main, Application, Interface, Server, AppGroup, Mtv, Funcs },
  data() {
    return {
      appData: {
        interface: 225,
        server: 1,
        appGroup: 2,
        mtv: 3,
        funcs: 4,
      },
    };
  },
  methods: {
    updateAppData(val, type) {
      this.appData[type] = +val;
    },
  },
  computed: {
    applicationTotal() {
      return Object.values(this.appData).reduce(
        (a, b) => Number(a) + Number(b),
        0
      );
    },
  },
  created() {
    bus.$on("update-input", (data) => {
      this.updateAppData(data.value || 0, data.type);
    });
  },
};
</script>
<style lang="scss" scoped>
.main-container {
  height: 100vh;
}
</style>