<template>
  <AppContainer
    icon="app"
    text="Application"
    :inputVal="inputValue"
    containerHeight="200"
    containerWidth="200"
    :disableInput="true"
  />
</template>
<script>
import AppContainer from "@/components/AppContainer";
export default {
  name: "Applications",
  components: { AppContainer },
  props: {
    inputValue: {
      type: [String, Number],
      default: 0,
    },
  },
};
</script>